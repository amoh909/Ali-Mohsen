import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import javax.swing.SpringLayout;

public class Hangman {
    public static void main(String[] args)throws FileNotFoundException{
        System.out.println("CMPS201 Hangman!\r\n" + //
                "I will think of a random word. You'll try to guess its letters. Every time you guess a letter that isn't in my word, a new body part of the hanging man appears.\r\n" + //
                "Guess correctly to avoid the gallows!"); 
        boolean oxy = true;
        String secretword = "";
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        System.out.print("What's the name of dictionary? ");
        String filen = input.next();
        int gamesplayed = 0;
        int gameswon = 0;
        int bestgame = 0;
        while (oxy == true) {
        gamesplayed++;
        Scanner wordsfile = new Scanner(new File(filen));
        int nb = wordsfile.nextInt();
        int randnb = rand.nextInt(nb)+1;
        for (int i = 1; i <= randnb; i++){
            secretword = wordsfile.next();
        }
        
        int left = 8;
        String all = "";
        String hint = "";
        for (int i = 0; i < secretword.length(); i++){
            hint += "-";
        }
            while (left > 0){
                String filename = "display"+left+".txt";
                Scanner fileread = new Scanner(new File(filename));
                while (fileread.hasNextLine()){
                    System.out.println(fileread.nextLine());
                }
                System.out.println("Secret word :" + hint);
                System.out.println("Your guesses :" + all);
                System.out.println("Guesses left: " + left);
                System.out.print("guess? ");
                String guesses = input.next();
                if (guesses.length()>1){
                    System.out.println("Please enter a letter from A to Z"); 
                    continue;
                }
                char guess = Character.toUpperCase(guesses.charAt(0));
                if (all.contains(guess+"")){
                    System.out.println("You already guessed that letter.");
                } 
                else if (secretword.contains(guess+"")){
                    System.out.println("Correct!");
                    all += guess;
                    for (int i = 0; i < secretword.length(); i++){
                        if (guess == secretword.charAt(i)){
                            hint = hint.substring(0,i) + guess + hint.substring(i+1,hint.length());
                        }
                    }
                } else {
                    System.out.println("Incorrect.");
                    left--;
                    all += guess;
                }
                if (hint.equals(secretword)){
                    System.out.println("You win! My word was " + secretword);
                    gameswon++;
                    if (left>bestgame){
                        bestgame = left;}
                    break;
                }
            } 
            if (left == 0){
                String filename = "display"+left+".txt";
                Scanner fileread = new Scanner(new File(filename));
                while (fileread.hasNextLine()){
                    System.out.println(fileread.nextLine());
                }
                System.out.println("You lose. My word was " + secretword);
            }
            while (true) {
                System.out.println("Play again (Y/N)?");
                String yn = input.next().toUpperCase();
                if (yn.equals("Y")){
                    break;
                }
                else if (yn.equals("N")){
                    oxy = false;
                    break;
                } else {
                    System.out.println("Illegal boolean format");
                }
            }   

        }
        System.out.println("Overall statistics:");
        System.out.println("Games played: " + gamesplayed);
        System.out.println("Games won: " + gameswon);
        System.out.println("Win percent: " + (((double)gameswon/(double)gamesplayed)*100)+ "%");
        System.out.println("Best game: " + bestgame + " guess(es) remaining");
        System.out.println("Thanks for playing!");
    }
}
