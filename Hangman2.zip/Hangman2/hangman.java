import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;

public class hangman {
    private static String secretWord;

    public static void run(String secretWord) throws FileNotFoundException {
        playOneGame(secretWord);
    }

    private void intro() {
        System.out.println("CMPS201 Hangman!\r\n" + //
                "I will think of a random word.\r\n" + //
                "You'll try to guess its letters.\r\n" + //
                "Every time you guess a letter\r\n" + //
                "that isn't in my word, a new body\r\n" + //
                "part of the hanging man appearsssssssssssssss.\r\n" + //
                "Guess correctly to avoid the gallows!");
        System.out.println();
    }

    private static void playOneGame(String secretWord) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        boolean oxy = true;
        int guessCount = 8;
        int gamesCount = 0;
        int gamesWon = 0;
        int best = 0;
        String filename = input.next();
        secretWord = getRandomWord(secretWord);
        displayHangman(guessCount);
        

        String guessedLetters = "";
        while (oxy == true){
            gamesCount++;
        
        while (guessCount > 0) {
            System.out.println("Secret word: " + createHint(secretWord, guessedLetters));
            System.out.println("Your guesses: " + guessedLetters);
            System.out.println("Guesses guessCount: " + guessCount);
            char guessedLetter = readGuess(guessedLetters);
            if (secretWord.contains(guessedLetter + "")) {
                guessedLetters += guessedLetter;
                System.out.println("Correct!");
            } else {
                guessedLetters += guessedLetter;
                System.out.println("Incorrect.");
                guessCount--;
            }
            if (secretWord.equals(createHint(secretWord, guessedLetters))) {
                System.out.println("You win! My word was " + secretWord);
                break;
            }
        }
        if (guessCount == 0) {
            displayHangman(guessCount);
            System.out.println("You lose. My word was " + secretWord);
        }
        return ;
    }
        while (true) {
            System.out.println("Play again (Y/N)?");
            String yn = input.next().toUpperCase();
            if (yn.equals("Y")){
                break;
            }
            else if (yn.equals("N")){
                oxy = false;
                break;
            } else {
                System.out.println("Illegal boolean format");
            }
        }   
        stats(gamesCount, gamesWon, best);
        


    }

    private static String createHint(String secretWord, String guessedLetters) {
        String secretword = "programmer";
        Scanner input = new Scanner(System.in);
        String hint = "";
        for (int i = 0; i < secretword.length(); i++) {
            hint += "-";
        }
        String guess = input.next();
        for (int i = 0; i < secretword.length(); i++) {
            if (guess == secretword.charAt(i) + "") {
                hint = hint.substring(0, i) + guess + hint.substring(i + 1, hint.length());
            }
        }
        return hint;

    }

    private static char readGuess(String guessedLetters) {
        Scanner input = new Scanner(System.in);
        String guess = input.next();
        if (guess.length() > 1) {
            System.out.println("Please enter a letter from A to Z");
        }
        char guesschar = Character.toUpperCase(guess.charAt(0));
        if (guessedLetters.contains(guess + "")) {
            System.out.println("You already guessed that letter.");
        }
        guessedLetters = "";
        guessedLetters += guess;

        return guesschar;
    }

    private static void displayHangman(int guessCount) throws FileNotFoundException {
        String filename = "display" + guessCount + ".txt";
        Scanner fileread = new Scanner(new File(filename));
        while (fileread.hasNextLine()) {
            System.out.println(fileread.nextLine());
        }

        filename = "display" + guessCount + ".txt";
        fileread = new Scanner(new File(filename));
        while (fileread.hasNextLine()) {
            System.out.println(fileread.nextLine());
        }

    }

    private static void stats(int gamesCount, int gamesWon, int best) {
        System.out.println("Overall statistics:");
        System.out.println("Games played: " + gamesCount);
        System.out.println("Games won: " + gamesWon);
        System.out.println("Win percent: " + (((double)gamesWon/(double)gamesCount)*100)+ "%");
        System.out.println("Best game: " + best + " guess(es) remaining");
        System.out.println("Thanks for playing!");
    }

    private static String getRandomWord(String filename) throws FileNotFoundException {
        Scanner wordsfile = new Scanner(new File(filename));
        int nb = wordsfile.nextInt();
        Random rand = new Random();
        int randnb = rand.nextInt(nb) + 1;
        String secretWord = "";
        for (int i = 1; i <= randnb; i++) {
            secretWord = wordsfile.next();
        }
        return secretWord;

    }

public static void main(String[] args) throws FileNotFoundException{
    run(secretWord);
}
}
