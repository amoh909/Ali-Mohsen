package Exercise_1;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.util.Scanner;

public class RunJavaPad implements ActionListener {
    JFrame frame;
    JTextArea textarea = new JTextArea(15, 25);
    JPanel buttons = new JPanel(new GridLayout(1, 6));
    JButton b1, b2, b3, b4, b5, b6;
    JPanel jPanel;
    File cfile;

    RunJavaPad() {
        frame = new JFrame("Microstuff JavaPad XP");
        frame.setLocation(0, 0);
        frame.setSize(300, 400);
        frame.setResizable(true);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel southPanel = new JPanel(new FlowLayout());
        frame.add(southPanel, BorderLayout.SOUTH);
        southPanel.add(new JLabel("Microstuff: We Can Do It."));
        southPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        textarea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textarea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        frame.add(scrollPane, BorderLayout.CENTER);

        b1 = new JButton("New");
        b2 = new JButton("Open");
        b3 = new JButton("Save");
        b4 = new JButton("Save as");
        b5 = new JButton("Load");
        b6 = new JButton("Quit");
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        buttons.add(b1);
        buttons.add(b2);
        buttons.add(b3);
        buttons.add(b4);
        buttons.add(b5);
        buttons.add(b6);
        frame.add(buttons, BorderLayout.NORTH);
     
        frame.setVisible(true);

    }

    private void sande() {
        if (cfile != null) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(cfile))) {
                String saved = textarea.getText();
                writer.write(saved);
            } catch (IOException exception) {
                JOptionPane.showMessageDialog(null, "Couldn't be saved", null, JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No file was chosen, open a file first", null,
                    JOptionPane.WARNING_MESSAGE);
        }
        System.exit(0);
    }

    public static void main(String[] args) throws FileNotFoundException {
        RunJavaPad JavaPad = new RunJavaPad();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b1) {
            textarea.setText("");
        } else if (e.getSource() == b2) {
            JFileChooser file = new JFileChooser();
            int result = file.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                cfile = file.getSelectedFile();
                try (Scanner s = new Scanner(cfile)) {
                    String ss = "";
                    while (s.hasNext()) {
                        ss += s.nextLine();
                    }
                    textarea.setText(ss);
                } catch (FileNotFoundException ef) {
                    JOptionPane.showMessageDialog(null, "File not found", null, JOptionPane.ERROR_MESSAGE);
                }
            }
        } else if (e.getSource() == b3) {
            if (cfile != null) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(cfile))) {
                    String saved = textarea.getText();
                    writer.write(saved);
                } catch (IOException exception) {
                    JOptionPane.showMessageDialog(null, "Couldn't be saved", null, JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No file was chosen, open a file first", null,
                        JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == b4) {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showSaveDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                cfile = fileChooser.getSelectedFile();
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(cfile))) {
                    String saved = textarea.getText();
                    writer.write(saved);
                } catch (IOException exception) {
                    JOptionPane.showMessageDialog(null, "Couldn't be saved", null, JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No file was chosen", null, JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == b5) {
            if (cfile != null) {
                try (Scanner s = new Scanner(cfile)) {
                    String ss = "";
                    while (s.hasNext()) {
                        ss += s.nextLine();
                    }
                    textarea.setText(ss);
                } catch (FileNotFoundException ef) {
                    JOptionPane.showMessageDialog(null, "File not found", null, JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No file was chosen", null, JOptionPane.WARNING_MESSAGE);
            }
        } else if (e.getSource() == b6) {
            int option = JOptionPane.showConfirmDialog(frame, "Quitting; Save?", "Quit",
                    JOptionPane.YES_NO_CANCEL_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                sande();
            } else if (option == JOptionPane.NO_OPTION) {

            }
        }
    }
}
